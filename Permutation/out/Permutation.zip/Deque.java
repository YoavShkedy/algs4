import java.lang.*;
import java.util.Iterator;

public class Deque<Item> implements Iterable<Item> {
    private int N;
    private Node first;
    private Node last;
    private class Node {
        Item item;
        Node next;
        Node previous;
    }

    // construct an empty deque
    public Deque() {
        first = null;
        last = null;
        N = 0;
    }

    // is the deque empty?
    public boolean isEmpty() {
        return (first == null);
    }

    // return the number of items on the deque
    public int size() {
        return N;
    }

    // add the item to the front
    public void addFirst(Item item) {
        if (item == null) {throw new IllegalArgumentException();}
        if (isEmpty()) { // if queue is empty
            first = new Node();
            last = first;
            first.item = item;
        } else { // if queue isn't empty
            if (last == first) {
                first = new Node();
                first.item = item;
                first.next = last;
            }
            else {
                Node oldFirst = first;
                first = new Node();
                first.item = item;
                first.next = oldFirst;
                oldFirst.previous = first;
            }
        }
        N++; // increment N
    }

    // add the item to the back
    public void addLast(Item item) {
        if (item == null) {throw new IllegalArgumentException();}
        if (isEmpty()) { // if queue is empty
            last = new Node();
            first = last;
            last.item = item;
        }
        else { // if queue isn't empty
            if (last == first) {
                last = new Node();
                last.item = item;
                last.next = null;
                last.previous = first;
            } else {
                Node oldLast = last;
                last = new Node();
                oldLast.next = last;
                last.item = item;
                last.next = null;
                last.previous = oldLast;
            }
        }
        N++; // increment N
    }

    // remove and return the item from the front
    public Item removeFirst() {
        if (isEmpty()) {throw new java.util.NoSuchElementException();}
        Item item = first.item; // a new item is made and assigned to first's item
        if (first.next == last) {
            first = last;
        }
        if (first.next == null) {
            if (last == first) {
                first = null;
                last = null;
            }
            if (last != null) {
                last.previous = null;
                first = last;
            }
            else {
                last = null;
            }
        }
        else {
            first = first.next; // move first one node forward
            first.previous = null;
        }
        N--; // decrement N
        return item;
    }

    // remove and return the item from the back
    public Item removeLast() {
        if (isEmpty()) {throw new java.util.NoSuchElementException();}
        Item item = last.item; // a new item is made and assigned to last's item
        if (last.previous == null) {
            if (last == first) {
                last = null;
                first = null;
            }
            if (first != null) {
                first.next = null;
                last = first;
            }
            else {
                first = null;
            }
        }
        else {
            last.previous = last;
            last.next = null;
        }
        N--; // decrement N
        return item;
    }

    // return an iterator over items in order from front to back
    public Iterator<Item> iterator() {
        return new ArrayIterator();
    }

    private class ArrayIterator implements Iterator<Item> {
        private Node current = first;

        @Override
        public boolean hasNext () {
            return current != null;
        }

        @Override
        public Item next () {
            if (current == null) {throw new java.util.NoSuchElementException();}
            Item item = current.item;
            current = current.next;
            return item;
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException();
        }
    }

    // unit testing (required)
    public static void main(String[]args) {
        Deque<String> dq = new Deque<>();
        dq.addFirst("BMW");
        dq.addLast("Mazda");
        dq.addFirst("Porsche");
        dq.addFirst("Ferrari");
        dq.addLast("Toyota");
        dq.addLast("Peugeot");
        System.out.println("There are currently " + dq.size() + " items in the list:");
        Iterator<String> iterator = dq.iterator();
        while (iterator.hasNext()) {
            String item = iterator.next();
            System.out.println(item);
        }
        System.out.println("Those were the items in the list.");
        System.out.println("We are now going to each time remove a couple items from the list.");
        System.out.println("The list size is currently " + dq.size() + ".");
        while (!dq.isEmpty()) {
            dq.removeFirst();
            dq.removeLast();
            System.out.println("The size of the list shrank to " + dq.size());
        }
        System.out.println("All the items in the list were removed!");
    }
}